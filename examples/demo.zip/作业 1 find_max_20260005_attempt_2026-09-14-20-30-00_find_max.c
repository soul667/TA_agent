int find_max(int arr[], int n) {
    int max = arr[0];

    if (arr[n - 1] > max) {
        max = arr[n - 1];
    }

    return max;
}
